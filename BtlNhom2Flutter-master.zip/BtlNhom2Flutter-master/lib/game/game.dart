abstract class Game {
  int get difficulty; // 1,2,3
}
