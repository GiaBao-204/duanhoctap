import 'game.dart';

class RecycleSortGame implements Game {
  @override
  final int difficulty;
  RecycleSortGame({required this.difficulty});
}
