class GameRegistry {
  // chỗ để đăng ký nhiều game nếu sau này mở rộng
}
