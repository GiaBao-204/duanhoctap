import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

// Screens
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'home_shell.dart';
import 'screens/recycle_sort_game_launcher.dart';
import 'game/types.dart';

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
  title: 'MobileApp',
  debugShowCheckedModeBanner: false,
  theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF00796B)),
  initialRoute: '/login',
  routes: {
    '/login': (_) => const LoginScreen(),
    '/signup': (_) => const SignupScreen(),
    '/shell': (_) => const HomeShell(),
    // ❌ Đừng khai báo '/game/recycle' ở đây nữa
  },
  onGenerateRoute: (settings) {
    if (settings.name == '/game/recycle') {
      final args = settings.arguments as Map<String, dynamic>;
      return MaterialPageRoute(
        builder: (_) => RecycleSortGameLauncher(
          treId: args['treId'] as String,
          treName: args['treName'] as String,
          difficulty: args['difficulty'] as GameDifficulty,
        ),
      );
    }
    return null;
  },
);
  }
}