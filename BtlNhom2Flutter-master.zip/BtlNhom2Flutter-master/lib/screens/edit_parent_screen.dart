import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/user_service.dart';

class EditParentScreen extends StatefulWidget {
  const EditParentScreen({super.key});

  @override
  State<EditParentScreen> createState() => _EditParentScreenState();
}

class _EditParentScreenState extends State<EditParentScreen> {
  final _fullNameCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _emailCtrl    = TextEditingController();
  final _phoneCtrl    = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _saving = false;
  bool _seeded = false; // chỉ seed controllers 1 lần khi stream có data

  @override
  void initState() {
    super.initState();
    _ensureProfile();
  }

  Future<void> _ensureProfile() async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;
    // tạo node users/{uid} nếu chưa có
    await UserService().createIfMissing(
      uid: me.uid,
      email: me.email ?? '',
      displayName: me.displayName,
    );
  }

  @override
  void dispose() {
    _fullNameCtrl.dispose();
    _usernameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;

    setState(() => _saving = true);
    try {
      await UserService().updateProfile(
        uid: me.uid,
        fullName: _fullNameCtrl.text.trim(),
        username: _usernameCtrl.text.trim(),
        email:    _emailCtrl.text.trim().toLowerCase(),
        phone:    _phoneCtrl.text.trim().replaceAll(' ', ''),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã lưu thay đổi')),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) {
      return const Scaffold(body: Center(child: Text('Vui lòng đăng nhập')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Chỉnh sửa phụ huynh')),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: UserService().watchProfile(me.uid),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snap.data;
          if (data == null) {
            // Chưa có node (vừa tạo xong hoặc rules chặn) → hiển thị hint
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Chưa có hồ sơ phụ huynh'),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _ensureProfile,
                      child: const Text('Tạo hồ sơ từ tài khoản'),
                    ),
                  ],
                ),
              ),
            );
          }

          // Seed controllers 1 lần từ DB
          if (!_seeded) {
            _fullNameCtrl.text = (data['fullName'] ?? '').toString();
            _usernameCtrl.text = (data['username'] ?? '').toString();
            _emailCtrl.text    = (data['email'] ?? me.email ?? '').toString();
            _phoneCtrl.text    = (data['phone'] ?? '').toString();
            _seeded = true;
          }

          return Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _field(
                  label: 'Họ và tên',
                  controller: _fullNameCtrl,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Vui lòng nhập họ tên' : null,
                ),
                _field(
                  label: 'Tên đăng nhập',
                  controller: _usernameCtrl,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Vui lòng nhập tên đăng nhập' : null,
                ),
                _field(
                  label: 'Email',
                  controller: _emailCtrl,
                  keyboard: TextInputType.emailAddress,
                  validator: (v) {
                    final t = v?.trim() ?? '';
                    if (t.isEmpty) return 'Vui lòng nhập email';
                    if (!t.contains('@')) return 'Email không hợp lệ';
                    return null;
                  },
                ),
                _field(
                  label: 'Số điện thoại',
                  controller: _phoneCtrl,
                  keyboard: TextInputType.phone,
                  validator: (v) {
                    final t = v?.trim() ?? '';
                    if (t.isEmpty) return null; // optional
                    if (t.length < 8) return 'SĐT chưa đúng';
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(
                          height: 22, width: 22,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Lưu thay đổi'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _field({
    required String label,
    required TextEditingController controller,
    TextInputType keyboard = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboard,
        validator: validator,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
