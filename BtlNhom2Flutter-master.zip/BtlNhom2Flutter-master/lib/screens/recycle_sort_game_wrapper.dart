import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/tre.dart';
import '../services/reward_service.dart';
import 'reward_screen.dart';
import 'package:mobileapp/game/types.dart'; // để dùng GameDifficulty

class RecycleSortGameWrapper extends StatefulWidget {
  const RecycleSortGameWrapper({super.key});

  @override
  State<RecycleSortGameWrapper> createState() => _RecycleSortGameWrapperState();
}

class _RecycleSortGameWrapperState extends State<RecycleSortGameWrapper> {
  late final Tre tre;
  late final GameDifficulty difficulty;
  bool _finishing = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    if (args == null || args['tre'] == null || args['difficulty'] == null) {
      // quay lại nếu thiếu tham số
      WidgetsBinding.instance.addPostFrameCallback((_) => Navigator.pop(context));
      return;
    }
    tre = args['tre'] as Tre;
    difficulty = args['difficulty'] as GameDifficulty;
  }

  // 👉 GỌI HÀM NÀY KHI GAME KẾT THÚC
  Future<void> finishGame(int correct, int wrong) async {
    if (_finishing) return;
    setState(() => _finishing = true);

    // Tính điểm: đúng +20, sai -10 (không âm dưới 0 nếu bạn muốn)
    final score = (correct * 20) - (wrong * 10);

    try {
      // Cộng điểm cho bé
      await RewardService().addPoints(tre.id, score);

      if (!mounted) return;

      // Thông báo nhanh
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kết quả: đúng $correct • sai $wrong • +$score điểm')),
      );

      // Điều hướng xem bảng thưởng của bé
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => RewardScreen(treId: tre.id)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lưu điểm thất bại: $e')),
      );
      setState(() => _finishing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(body: Center(child: Text('Vui lòng đăng nhập')));
    }

    // Map độ khó sang bất kỳ tham số bạn cần
    final diffNum = switch (difficulty) {
      GameDifficulty.easy => 1,
      GameDifficulty.medium => 2,
      GameDifficulty.hard => 3,
    };

    return Scaffold(
      appBar: AppBar(
        title: Text('Phân loại rác • ${tre.hoTen} • ${_labelDifficulty(difficulty)}'),
      ),
      body: Stack(
        children: [
          // ===================  TODO(1): NHÚNG MÀN CHƠI THẬT CỦA BẠN  ===================
          // Ví dụ (giả sử game_play_screen.dart của bạn có widget GamePlayScreen):
          //
          // GamePlayScreen(
          //   game: RecycleSortGame(difficulty: diffNum),
          //   onFinish: (int correct, int wrong) => finishGame(correct, wrong),
          // )
          //
          // Nếu API là Provider/Repository khác, bạn nhúng theo đúng docs file game của bạn.
          // Ở cuối ván, nhớ gọi finishGame(correct, wrong).
          // --------------------------------------------------------------------------------

          // Placeholder UI tạm thời để bạn test luồng lưu điểm:
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.recycling, size: 72, color: Colors.green),
                const SizedBox(height: 12),
                Text('Chơi game phân loại rác (độ khó: $diffNum)'),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _finishing ? null : () => finishGame(7, 2), // ví dụ: đúng 7 sai 2
                  child: const Text('KẾT THÚC • GIẢ LẬP (đúng 7, sai 2)'),
                ),
              ],
            ),
          ),

          if (_finishing)
            const Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: LinearProgressIndicator(),
              ),
            ),
        ],
      ),
    );
  }

  String _labelDifficulty(GameDifficulty d) {
    return switch (d) {
      GameDifficulty.easy => 'Dễ',
      GameDifficulty.medium => 'Vừa',
      GameDifficulty.hard => 'Khó',
    };
  }
}
