// lib/services/user_service.dart
import 'package:firebase_database/firebase_database.dart';

class UserService {
  final _db = FirebaseDatabase.instance.ref('users');

  // ========= API CŨ – giữ nguyên =========
  Future<void> saveProfile({
    required String uid,
    required String name,        // code cũ dùng 'name'
    required String username,
    required String email,
    required String phone,
  }) {
    // Lưu cả 'name' và 'fullName' để tương thích 2 chiều
    return _db.child(uid).update({
      'id': uid,
      'name': name,              // giữ lại cho các màn cũ
      'fullName': name,          // khóa CHUẨN mới
      'username': username,
      'email': email,
      'phone': phone,
      'updatedAt': DateTime.now().toIso8601String(),
    });
  }

  Future<Map<String, dynamic>?> getProfile(String uid) async {
    final snap = await _db.child(uid).get();
    if (!snap.exists || snap.value == null) return null;
    final raw = Map<String, dynamic>.from(snap.value as Map);
    return _normalize(raw);
  }

  // ========= API MỚI – khuyên dùng từ nay =========

  /// Cập nhật theo khóa chuẩn 'fullName'
  Future<void> updateProfile({
    required String uid,
    String? fullName,
    String? username,
    String? email,
    String? phone,
  }) {
    final data = <String, dynamic>{
      if (fullName != null) 'fullName': fullName,
      if (fullName != null) 'name': fullName, // giữ đồng bộ cho code cũ
      if (username != null) 'username': username,
      if (email != null) 'email': email,
      if (phone != null) 'phone': phone,
      'updatedAt': DateTime.now().toIso8601String(),
    };
    return _db.child(uid).update(data);
  }

  /// Lắng nghe realtime và chuẩn hoá key cho UI
  Stream<Map<String, dynamic>?> watchProfile(String uid) {
    return _db.child(uid).onValue.map((e) {
      if (!e.snapshot.exists || e.snapshot.value == null) return null;
      final raw = Map<String, dynamic>.from(e.snapshot.value as Map);
      return _normalize(raw);
    });
  }

  // ========= Helpers =========

  /// Gom key về format thống nhất cho UI:
  /// { id, fullName, username, email, phone }
  Map<String, dynamic> _normalize(Map<String, dynamic> raw) {
    final fullName = (raw['fullName'] ?? raw['name'] ?? '').toString();
    final username = (raw['username'] ?? raw['userName'] ?? '').toString();
    final email    = (raw['email'] ?? '').toString();
    final phone    = (raw['phone'] ?? raw['phoneNumber'] ?? '').toString(); 

    return {
      'id': raw['id'] ?? '',
      'fullName': fullName,
      'username': username,
      'email': email,
      'phone': phone,
    };
  }

    Future<bool> exists(String uid) async {
    final s = await _db.child(uid).get();
    return s.exists && s.value != null;
  }

  /// Tạo hồ sơ cơ bản nếu chưa có (lấy thông tin từ Auth)
  Future<void> createIfMissing({
    required String uid,
    required String email,
    String? displayName,
  }) async {
    final ok = await exists(uid);
    if (ok) return;
    await _db.child(uid).set({
      'id': uid,
      'fullName': displayName ?? '',
      'name': displayName ?? '',
      'username': (email.split('@').first),
      'email': email,
      'phone': '',
      'createdAt': DateTime.now().toIso8601String(),
      'updatedAt': DateTime.now().toIso8601String(),
    });
  }

}
