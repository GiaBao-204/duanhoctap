import 'dart:async';
import 'package:flutter/foundation.dart'; // 👈 thêm dòng này
import '../models/play_time.dart';

class TimeService {
  Timer? _ticker;

  /// Đếm lùi đến khi hết thời gian; gọi onTick mỗi giây và onDone khi kết thúc.
  void startCountdown(
  PlayTime playTime, {
  required void Function(Duration) onTick,
  required VoidCallback onDone,
}) {
  _ticker?.cancel();

  // tick đầu tiên
  final remain = playTime.remaining;
  onTick(remain);
  if (remain <= Duration.zero) {
    onDone();
    return;
  }

  // timer lặp
  _ticker = Timer.periodic(const Duration(seconds: 1), (timer) {
    final remain = playTime.remaining;
    onTick(remain);
    if (remain <= Duration.zero) {
      timer.cancel();
      onDone();
    }
  });
}


  void dispose() => _ticker?.cancel();
}
