class PlayTime {
  final Duration limit; // thời gian giới hạn người chơi
  final DateTime startAt; // thời điểm bắt đầu giới hạn

  const PlayTime({required this.limit, required this.startAt});

  DateTime get endAt => startAt.add(limit);
  Duration get remaining {
    final now = DateTime.now();
    if (now.isAfter(endAt)) return Duration.zero;
    return endAt.difference(now);
  }
}
